
public class MineSweeper {

	public static void main(String[] args) {
		MyMineModel minemodel = new MyMineModel();
		MineView gameClient = new MineView(minemodel, 800, 600);
		
		
	}
	
}
