
public class MyCell implements Cell {
	

	private int row;
	private int column;
	private boolean visibility;
	private boolean flagged;
	private boolean isamine;
	private int neighbors;
	
	MyCell(int row, int column){
		
		this.row = row;
		this.column = column;
		this.isamine = false;
		this.flagged = false;
		this.visibility = false;
		this.neighbors = 0;
	}
	
	//int rows = 10;
	//int columns = 20;
	//int[][] data = new int[rows][columns]; //2D array
	//data[3][5] = 4;
	//for (row:data){
	//	for (column:data){
			
	//	}
		
	//}

	/** Returns the row number of this cell. */
	  public int getRow(){
		  return this.row;
	  }
	  
	  /** Returns the column number of this cell. */
	  public int getCol(){
		  return this.column;
	  }
	  
	  //makes the cell visible.
	  public void makeVisible(){
		  if (this.visibility == false){
			  this.visibility = true;
		  }
	  }
	  
	  /** Returns true if this cell is visible, meaning that its number of neighboring mines should be displayed. */
	  public boolean isVisible(){
		  return this.visibility;
	  }
	  
	  // causes the cell to be a mine.
	  
	  public void placeMine(){
		  if (this.isamine == false){
			  this.isamine = true;
		  }
	  }

	  /** Returns true if this cell contains a mine (regardless of whether it is visible or has been flagged). */
	  public boolean isMine(){
		  return this.isamine;
	  }
	  
	  /** Flags the cell */
	  public void flagCell(){
		  if (this.flagged == false && this.visibility == false){
			  this.flagged = true;
		  } else{
			  this.flagged = false;
		  }
		  
	  }
	  
	  /** Returns true if this cell has been flagged (regardless of whether it is visible or contains a mine). */
	  public boolean isFlagged(){
		  return this.flagged;
	  }
	  
	  
	  public void plugneighbors(int neighbors){
		  this.neighbors = neighbors;
	  }
	  
	  /** Returns the number of mines that are in cells that are adjacent to this one.  Most cells have
	   * eight neighbors (N, S, E, W, NE, NW, SE, SW).  Cells along the edges of the field or cells in the
	   * corners have fewer neighbors.  Mines are counted regardless of whether or not they are visible
	   * or flagged.  If there is a mine in the current cell, it is not counted.
	   */
	  public int getNeighborMines(){
		  return this.neighbors;
	  }
	
}
