import java.util.Random;
import java.time.Duration;

public class MyMineModel {
	
	
	private int rows;
	private int columns;
	private int mines;
	private int flags = 0;
	private int time;
	private MyCell cellArray[][];
	private long startTime;
	private boolean gameEnd;
	private boolean death;
	private boolean gameStart;

	//casting
	// int i = 7;
	//double d = (double) i;
	//
	//animal a = new Bird();
	//a.eat()
	//a.fly() <-- NOT valid
	//((Bird)a).fly() <- valid
	
	  /** Starts a new game of Mine Sweeper.  This method creates a field of the indicated size,
	   * initializes it, and places the indicated number of mines on the field.
	   * @param numRows the number of rows for the field
	   * @param numCols the number of columns for the field
	   * @param numMines the number of mines to place in the field
	   */
	  public void newGame(int numRows, int numCols, int numMines){
		  this.startTime = System.currentTimeMillis()/1000;
		  this.rows = numRows;
		  this.columns = numCols;
		  this.mines = numMines;
		  this.gameEnd = false;
		  this.death = false;
		  this.gameStart = true;
		  this.cellArray = new MyCell [this.rows][this.columns];
		  //System.out.println("Cell array " + cellArray.length);
		  //System.out.println("Columns " + this.columns);
		  //System.out.println("Rows " + this.rows);
		  for (int x = 0; x < this.rows; x += 1){
			  for (int y = 0; y < this.columns; y+= 1){
				  cellArray[x][y] = new MyCell(x,y);
			  }
		  }
		  boolean[][] mineArray = new boolean [this.rows][this.columns];
		  Random RandGen = new Random();
		  for (int looper= 1; looper <= this.mines; looper +=1){
			  int xcoord = RandGen.nextInt(this.rows);
			  int ycoord = RandGen.nextInt(this.columns);
			  if (mineArray[xcoord][ycoord] == false){
				  mineArray[xcoord][ycoord] = true;
				  cellArray[xcoord][ycoord].placeMine();  
			  }  
			  else {
				  looper = looper-1;
			  }
		  }
		  for (int x = 0; x < this.rows; x += 1){
			  for (int y = 0; y < this.columns; y+= 1){
				  findNeighbors(cellArray[x][y]);
			  }
		  }

		  
		  
	  }
	  
	  /** Returns the number of rows in the field. */
	  public int getNumRows(){
		  return rows;
	  }
	  
	  /** Returns the number of columns in the field. */
	  public int getNumCols(){
		  return columns;
	  }
	  
	  /** Returns the total number of mines in the field. */
	  public int getNumMines(){
		  return mines;
	  }
	  
	  /** Returns the number of flags that have been placed in the field. */
	  public int getNumFlags(){
		  int flags = 0;
		  for (int x = 0; x < this.rows; x += 1){
			  for (int y = 0; y < this.columns; y+= 1){
				  if (cellArray[x][y].isFlagged()){
					  flags +=1;
				  }
			  }
		  }
		  return flags;
	  }
	  
	  
	  /** Returns the number of seconds that have elapsed since this game started. */
	  public int getElapsedSeconds(){
		  long time = System.currentTimeMillis()/1000;
		  long duration = time - this.startTime;
		  return (int) duration;
		  
	  }
	  
	  /** Returns the Cell in the field at the given coordinates.
	   * @param row the row number of the cell [precondition: <code> 0 <= row < getNumRows()</code>]
	   * @param col the column number of the cell [precondition: <code> 0 <= col < getNumCols()</code>]
	   * @return a valid, non-null Cell object
	   */
	  public MyCell getCell(int row, int col){
		  return cellArray[row][col];
	  }
	  
	  /** Called when the player has stepped onto the cell at the given coordinates.
	   * This cell is now made visible.  If it is a mine, the player is dead and the game is over.
	   * If it is a safe (non-mine) cell with no neighboring mines (a zero cell), then every cell
	   * that can be reached from this one by only stepping on zero cells should be made visible as well.
	   * @param row the row number of the cell [precondition: <code> 0 <= row < getNumRows()</code>]
	   * @param col the column number of the cell [precondition: <code> 0 <= col < getNumCols()</code>]
	   */
	  public void stepOnCell(int row, int col){
		  MyCell cell = cellArray[row][col];
		  if (cell.isFlagged() == false){
			  cell.makeVisible();
			  if (cell.isMine()){
				  this.gameEnd = true;
				  this.death = true;
				  return;
			  }
			  if (cell.getNeighborMines() == 0){
				  for (int neighborx = (cell.getRow() - 1); neighborx <= (cell.getRow() + 1); neighborx += 1){
					  for (int neighbory = cell.getCol() - 1; neighbory <= (cell.getCol() + 1); neighbory += 1){
						  if (exists(neighborx, neighbory)){
							  if (cellArray[neighborx][neighbory].isVisible() == false){  
								  cellArray[neighborx][neighbory].makeVisible();
								  if (cellArray[neighborx][neighbory].getNeighborMines() == 0){
									  stepOnCell(neighborx, neighbory);
								  }
							  }
						  }
					  }
				  }
			  }
		  }
	  }
	  
	  public boolean altReveal(MyCell cell){
		  int nearbymines = cell.getNeighborMines();
		  int nearbyflags = 0;
		  for (int neighborx = (cell.getRow() - 1); neighborx <= (cell.getRow() + 1); neighborx += 1){
			  for (int neighbory = cell.getCol() - 1; neighbory <= (cell.getCol() + 1); neighbory += 1){
				  if (exists(neighborx, neighbory)){
					  if (cellArray[neighborx][neighbory].isFlagged() == true){  
						  nearbyflags += 1;
					  }
				  }
			  }
		  }
		  if (nearbymines == nearbyflags){
			  return true;
		  }
		  return false;
	  }

	
	  public boolean exists(int x, int y){
		  if (x <= this.rows - 1 && x >= 0 && y <= this.columns - 1 && y >= 0){
			  return true;
		  }else{
			  return false;
		  }
	  }

	  public void findNeighbors(MyCell cell){
		  int nearbymines = 0;
		  for (int neighborx = (cell.getRow() - 1); neighborx <= (cell.getRow() + 1); neighborx += 1){
			for (int neighbory = (cell.getCol() - 1); neighbory <= (cell.getCol() + 1); neighbory += 1){
				if (exists(neighborx, neighbory)){
					if (cellArray[neighborx][neighbory].isMine()){
						nearbymines += 1;
						  }
					  }
				  }
			  }
		  cell.plugneighbors(nearbymines);
	  }
		  

	  
	  /** Called when the player wants to change the flagged status of a cell.  
	   * If the indicated cell has no flag, then place a flag there.
	   * If the indicated cell already has a flag, then remove it.
	   * Note that it is safe to place a flag on any cell, even if it has a mine.
	   * @param row the row number of the cell [precondition: <code> 0 <= row < getNumRows()</code>]
	   * @param col the column number of the cell [precondition: <code> 0 <= col < getNumCols()</code>]
	   */
	  public void placeOrRemoveFlagOnCell(int row, int col){
		  cellArray[row][col].flagCell();
	  }
	  
	  /** Returns true if a game was started, whether or not it has ended.  
	   * Returns false only if no game has ever been started.
	   */
	  public boolean isGameStarted(){
		  if (this.gameStart == true){
			  return true;
		  } else{
			  return false;
		  }
	  }
	  
	  /** Returns true if the current game has ended.  
	   * Returns false if the current game is running.
	   * If the game hasn't started, then the value returned by this method is not defined.
	   */
	  
	  public void DIE(){
		  this.gameEnd = true;
		  this.death = true;
		  revealMines();
	  }
	  
	  public void revealMines(){
		  for (int x = 0; x < this.rows; x += 1){
			  for (int y = 0; y < this.columns; y+= 1){
				  if (cellArray[x][y].isMine()){
					  cellArray[x][y].makeVisible();
				  }
			  }
		  }
	  }
	  
	  public boolean isGameOver(){
		  if (this.gameEnd == true){
			  return true;
		  } else{
			  return false;
		  }
	  }
	  
	  /** Returns true if the player is dead, because they stepped on a mine.
	   * Returns false if the player has not yet stepped on a mine.
	   */
	  public boolean isPlayerDead(){
		  if (this.death == true){
			  return true;
		  } else {
			  return false;
		  }
	  }
	  
	  /** Returns true if the player has won the current game, by exposing every non-mine cell.  
	   * Returns false if player hasn't won (either the game hasn't started, it is still going, or the player is dead).
	   */
	  public boolean isGameWon(){
		  //System.out.println(this.rows* this.columns - this.mines);
		  int winnercount = 0;
		  for (int x = 0; x < this.rows; x += 1){
			  for (int y = 0; y < this.columns; y+= 1){
				  if (cellArray[x][y].isVisible()){
					  winnercount += 1;
					  //System.out.println(winnercount);
				  }
			  }
		  }
		  int endvalue = ((this.rows* this.columns) - this.mines);
		  //System.out.println(endvalue);
		  
		  if (winnercount >= endvalue){
			  //System.out.println("yay");
			  this.gameEnd = true;
			  return true;
			  } else{
			  return false;
			  }
	  }


}
